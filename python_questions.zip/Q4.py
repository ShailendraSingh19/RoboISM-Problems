#Q.4
s = ("number")
for letter in s:
    doubled = letter*2
    print(doubled,end='')