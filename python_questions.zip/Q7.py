from collections import Counter
list1 = [12,23,34,88,7,5,4,2,2,2,2,2,3,3,3]
items = Counter(list1)
print(items)